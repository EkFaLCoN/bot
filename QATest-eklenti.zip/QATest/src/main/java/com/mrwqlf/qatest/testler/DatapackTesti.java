package com.mrwqlf.qatest.testler;

import com.mrwqlf.qatest.Akis;
import com.mrwqlf.qatest.Cerceve;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Datapack'leri dosya seviyesinde inceler — calistirmadan, oyuna girmeden.
 *
 * Yakaladiklari:
 *  - Cagrilan ama var olmayan fonksiyonlar (sessizce hicbir sey yapmaz)
 *  - tick/load tag'inde listelenip dosyasi olmayan fonksiyonlar
 *  - Her tick calisan fonksiyonlarda KOSULSUZ particle/playsound —
 *    "elde kilic olmasa da parcacik cikiyor" hatasinin kaynagi tam olarak budur
 *  - Sinirsiz @a / @e secicileri (her tick tum oyunculari/varliklari tarar)
 *  - Bozuk veya eksik pack.mcmeta
 */
public final class DatapackTesti implements Test {

    @Override public String ad() { return "datapack"; }
    @Override public String aciklama() { return "Datapack fonksiyonlarini dosya seviyesinde tarar (kosulsuz efekt, kirik cagri)"; }

    // function ns:yol/adi
    private static final Pattern CAGRI = Pattern.compile("\\bfunction\\s+([a-z0-9_.-]+:[a-z0-9_./-]+)");
    /**
     * Metin komutlari: bunlarin icinde gecen "function ruby:test" gibi ifadeler
     * gercek bir cagri degil, oyuncuya gosterilen yazidir. Onceki surum bunlari
     * kirik cagri sanip yanlis alarm veriyordu.
     */
    private static final Pattern METIN_KOMUTU = Pattern.compile(
            "^\\s*(say|tell|tellraw|msg|w|me|title|subtitle|actionbar|bossbar)\\b");
    // satirin efekt komutu ile BASLAMASI = hicbir kosul yok
    private static final Pattern KOSULSUZ_EFEKT = Pattern.compile("^\\s*(particle|playsound|summon)\\s+");
    private static final Pattern GENIS_SECICI = Pattern.compile("(as|at)\\s+@[ae](?!\\[)");
    /** Satirin bir kosul/filtre icerip icermedigi. */
    private static final Pattern KOSUL = Pattern.compile(
            "\\b(if|unless)\\s+(entity|block|blocks|data|score|predicate|items|dimension|loaded|biome|function)\\b"
            + "|@[aepsr]\\[");

    private record Fonksiyon(String tamAd, String icerik) {}

    @Override
    public void kur(Akis a, Cerceve c) {
        a.adim("bolum", x -> x.rapor().grup("Datapack dosya analizi"));

        a.adim("tara", x -> {
            List<File> paketler = paketleriBul();
            if (paketler.isEmpty()) {
                var bakilan = com.mrwqlf.qatest.Kesif.datapackKlasorleri();
                x.rapor().uyari("Datapack bulunamadi. Bakilan yerler: "
                        + (bakilan.isEmpty() ? "(hicbir datapacks/ klasoru yok)"
                                             : bakilan.stream().map(File::getAbsolutePath).toList())
                        + " — datapack'lerin baska bir yerdeyse klasoru soyle, arama listesine ekleyeyim");
                return;
            }
            x.rapor().ok(paketler.size() + " datapack bulundu, inceleniyor");

            for (File paket : paketler) {
                String paketAdi = paket.getParentFile().getParentFile().getName() + "/" + paket.getName();
                try {
                    analizEt(x, paketAdi, paket);
                } catch (Throwable t) {
                    x.rapor().acik(paketAdi + ": analiz sirasinda hata -> "
                            + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
            }
        });
    }

    private List<File> paketleriBul() {
        List<File> hepsi = new ArrayList<>();
        for (File klasor : com.mrwqlf.qatest.Kesif.datapackKlasorleri()) {
            File[] icerik = klasor.listFiles();
            if (icerik == null) continue;
            for (File f : icerik) if (!f.getName().startsWith(".")) hepsi.add(f);
        }
        return hepsi;
    }

    // ---------------------------------------------------------------

    private void analizEt(Cerceve x, String paketAdi, File paket) throws Exception {
        Map<String, String> dosyalar = dosyalariOku(paket);   // yol -> icerik

        if (!dosyalar.containsKey("pack.mcmeta")) {
            x.rapor().acik(paketAdi + ": pack.mcmeta yok — bu paket hic yuklenmez");
            return;
        }

        // fonksiyonlari topla: data/<ns>/function(s)/<yol>.mcfunction
        Map<String, Fonksiyon> fonksiyonlar = new LinkedHashMap<>();
        Set<String> tickFonksiyonlari = new LinkedHashSet<>();
        List<String> tagDosyalari = new ArrayList<>();

        Pattern yolKalibi = Pattern.compile("^data/([a-z0-9_.-]+)/functions?/(.+)\\.mcfunction$");

        // ONCE tum fonksiyonlari indeksle. Onceki surumde tag kontrolu bu dongunun
        // icinde yapiliyordu ve henuz okunmamis fonksiyonlar "yok" sanilıyordu.
        for (var giris : dosyalar.entrySet()) {
            Matcher m = yolKalibi.matcher(giris.getKey().replace('\\', '/'));
            if (m.matches()) {
                String tamAd = m.group(1) + ":" + m.group(2);
                fonksiyonlar.put(tamAd, new Fonksiyon(tamAd, giris.getValue()));
            }
        }

        // SONRA tag dosyalarini kontrol et
        Map<String, List<String>> tagIcerik = new LinkedHashMap<>();
        for (var giris : dosyalar.entrySet()) {
            String yol = giris.getKey().replace('\\', '/');
            if (!yol.matches("^data/minecraft/tags/functions?/(tick|load)\\.json$")) continue;
            tagDosyalari.add(yol);
            List<String> degerler = tagDegerleri(giris.getValue());
            tagIcerik.put(yol, degerler);
            boolean tickMi = yol.contains("tick");
            for (String deger : degerler) {
                if (tickMi) tickFonksiyonlari.add(deger);
                if (deger.startsWith("#")) continue;
                if (fonksiyonlar.containsKey(deger)) continue;
                x.rapor().acik(paketAdi + ": " + (tickMi ? "tick" : "load")
                        + " tag'inde \"" + deger + "\" listeli ama boyle bir fonksiyon dosyasi YOK");
            }
        }

        if (fonksiyonlar.isEmpty()) {
            x.rapor().uyari(paketAdi + ": hic .mcfunction dosyasi yok (sadece tarif/loot paketi olabilir)");
        } else {
            x.rapor().ok(paketAdi + ": " + fonksiyonlar.size() + " fonksiyon, "
                    + tickFonksiyonlari.size() + " tanesi her tick calisiyor");
        }

        if (tagDosyalari.isEmpty() && !fonksiyonlar.isEmpty()) {
            x.rapor().uyari(paketAdi + ": tick/load tag dosyasi yok — fonksiyonlar sadece elle cagrilabiliyor");
        }

        // --- kirik fonksiyon cagrilari ---
        int kirik = 0;
        for (Fonksiyon f : fonksiyonlar.values()) {
            for (String satir : f.icerik().split("\n")) {
                String s = satir.strip();
                if (s.isEmpty() || s.startsWith("#")) continue;
                if (METIN_KOMUTU.matcher(s).find()) continue;   // say/tellraw icindeki metin
                Matcher m = CAGRI.matcher(s);
                while (m.find()) {
                    String hedef = m.group(1);
                    if (fonksiyonlar.containsKey(hedef)) continue;
                    if (hedef.startsWith("minecraft:")) continue;   // vanilla olabilir
                    kirik++;
                    x.rapor().acik(paketAdi + " / " + f.tamAd() + ": var olmayan fonksiyon cagriliyor -> "
                            + hedef + " (sessizce hicbir sey yapmaz)");
                }
            }
        }
        if (kirik == 0 && !fonksiyonlar.isEmpty())
            x.rapor().ok(paketAdi + ": tum fonksiyon cagrilari gecerli");

        // --- her tick calisan fonksiyonlarda kosulsuz efekt ---
        // Bir fonksiyona SADECE kosullu cagrilarla ulasiliyorsa, icindeki
        // "particle"/"playsound" satirlari zaten kosula bagli demektir.
        // Onceki surum bunu ayirt etmiyor ve cok sayida yanlis pozitif uretiyordu.
        record Dugum(String ad, boolean korumasiz) {}

        Set<String> gezildi = new HashSet<>();
        Deque<Dugum> kuyruk = new ArrayDeque<>();
        for (String t : tickFonksiyonlari) kuyruk.add(new Dugum(t, true));
        int kosulsuz = 0, genisSecici = 0;

        while (!kuyruk.isEmpty()) {
            Dugum d = kuyruk.poll();
            String ad = d.ad();
            if (!gezildi.add(ad + "|" + d.korumasiz())) continue;
            Fonksiyon f = fonksiyonlar.get(ad);
            if (f == null) continue;

            int satirNo = 0;
            for (String satir : f.icerik().split("\n")) {
                satirNo++;
                String s = satir.strip();
                if (s.isEmpty() || s.startsWith("#")) continue;

                boolean satirKosullu = KOSUL.matcher(s).find();

                // cagrilan alt fonksiyonlari zincire kat; cagri kosulluysa
                // hedef fonksiyon "korumali" sayilir
                if (!METIN_KOMUTU.matcher(s).find()) {
                    Matcher cm = CAGRI.matcher(s);
                    while (cm.find()) {
                        kuyruk.add(new Dugum(cm.group(1), d.korumasiz() && !satirKosullu));
                    }
                }

                if (d.korumasiz() && KOSULSUZ_EFEKT.matcher(s).find()) {
                    kosulsuz++;
                    x.rapor().acik(String.format(
                            "%s / %s satir %d: her tick KOSULSUZ calisan efekt -> \"%s\". "
                            + "Bu komut hicbir sarta bagli degil; ozel esya elde olmasa bile calisir. "
                            + "Basina \"execute as @a[nbt={SelectedItem:{...}}] at @s run\" gibi bir kosul koy.",
                            paketAdi, f.tamAd(), satirNo, kisalt(s)));
                }

                Matcher gm = GENIS_SECICI.matcher(s);
                if (gm.find() && !satirKosullu) {
                    genisSecici++;
                    x.rapor().uyari(String.format(
                            "%s / %s satir %d: her tick FILTRESIZ tum oyuncular taraniyor -> \"%s\". "
                            + "Satirda hicbir kosul yok; @a[tag=...] veya @a[scores={...}] gibi bir "
                            + "filtre koyarsan sunucu her tick tum oyunculari gezmez.",
                            paketAdi, f.tamAd(), satirNo, kisalt(s)));
                }
            }
        }

        if (!tickFonksiyonlari.isEmpty() && kosulsuz == 0)
            x.rapor().ok(paketAdi + ": tick zincirinde kosulsuz efekt komutu yok");
        if (!tickFonksiyonlari.isEmpty() && genisSecici == 0)
            x.rapor().ok(paketAdi + ": tick zincirinde sinirsiz secici yok");
    }

    private static String kisalt(String s) {
        return s.length() <= 70 ? s : s.substring(0, 67) + "...";
    }

    /** tag json'undan values listesini cikarir (basit ayristirma, gson'suz da calisir). */
    private static List<String> tagDegerleri(String json) {
        List<String> liste = new ArrayList<>();
        Matcher m = Pattern.compile("\"([a-z0-9_.-]+:[a-z0-9_./-]+)\"").matcher(json);
        while (m.find()) liste.add(m.group(1));
        return liste;
    }

    /** Paketi klasor ya da zip olarak okur: yol -> icerik. */
    private static Map<String, String> dosyalariOku(File paket) throws Exception {
        Map<String, String> harita = new LinkedHashMap<>();

        if (paket.isDirectory()) {
            var kok = paket.toPath();
            try (var akis = Files.walk(kok)) {
                for (var p : akis.toList()) {
                    if (!Files.isRegularFile(p)) continue;
                    String ad = kok.relativize(p).toString().replace('\\', '/');
                    if (!(ad.endsWith(".mcfunction") || ad.endsWith(".json") || ad.equals("pack.mcmeta"))) continue;
                    try { harita.put(ad, Files.readString(p, StandardCharsets.UTF_8)); }
                    catch (Exception yoksay) { /* ikili dosya */ }
                }
            }
            return harita;
        }

        if (paket.getName().toLowerCase(Locale.ROOT).endsWith(".zip")) {
            try (ZipFile zip = new ZipFile(paket)) {
                var e = zip.entries();
                while (e.hasMoreElements()) {
                    ZipEntry z = e.nextElement();
                    if (z.isDirectory()) continue;
                    String ad = z.getName().replace('\\', '/');
                    if (!(ad.endsWith(".mcfunction") || ad.endsWith(".json") || ad.equals("pack.mcmeta"))) continue;
                    try (var r = new InputStreamReader(zip.getInputStream(z), StandardCharsets.UTF_8)) {
                        StringBuilder sb = new StringBuilder();
                        char[] buf = new char[8192];
                        int n;
                        while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                        harita.put(ad, sb.toString());
                    }
                }
            }
        }
        return harita;
    }
}
