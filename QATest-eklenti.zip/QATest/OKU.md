# QATest — tek komutla tum sunucuyu denetleyen QA botu

```
/qatest calistir
```

Bu tek komut her seyi kendisi bulur ve sirayla dener. Elle liste tutman gerekmez:
silah kodlari SinifSistemi'nin `Silah` enum'undan, sinif kodlari `Sinif` enum'undan,
datapack'ler dunya klasorlerinden, dunyalar sunucudan okunur. Eklentiye yeni bir
silah ekledigin anda test onu da kapsar.

Bulunan her sorun **hangi eklentide / hangi datapack'te / hangi dosyanin kacinci
satirinda** oldugu yazilarak raporlanir.

---

## 1. Sunucu sagligi

- Yuklu ama **acilmamis** eklenti var mi (konsolda acilis hatasi almis demektir)
- SinifSistemi ve Multiverse-Core calisiyor mu, hangi surumde
- Her dunyanin spawn noktasi guvenli mi (altinda blok var mi, lav icinde mi)
- Dunya siniri yanlislikla kucultulmus mu, otomatik kayit kapali mi
- Sunucuda kac ozel silah ve kac sinif bulundu, sinifsiz kalan silah var mi

## 2. Datapack analizi — dosya seviyesinde, calistirmadan

Her dunyanin `datapacks/` klasorundeki her paket (klasor ya da zip) acilir ve
fonksiyonlari okunur:

- **`pack.mcmeta` yok / bozuk / `pack_format` eksik** → paket sessizce hic yuklenmez
- **`supported_formats` yok** → sunucu surumu degisince paket aniden devre disi kalir
- **Cagrilan ama var olmayan fonksiyon** → o satir sessizce hicbir sey yapmaz
- **tick/load tag'inde listelenip dosyasi olmayan fonksiyon**
- **Her tick calisan zincirde KOSULSUZ `particle` / `playsound` / `summon`** —
  "elde kilic olmasa da parcaciklar cikiyor" hatasinin kaynagi tam olarak budur.
  Rapor sana dosya adini, satir numarasini ve komutun kendisini verir.
- **Kosesiz `@a` / `@e` secicileri** — her tick tum oyunculari/varliklari tarar;
  hem TPS dusurur hem istenmeyen hedeflere uygulanir

Tick zinciri takip edilir: `tick.json` → cagirdigi fonksiyonlar → onlarin cagirdiklari.
Yani ucuncu seviyedeki bir fonksiyondaki kosulsuz efekt de yakalanir.

## 3. Sinif ozellikleri

Beklenen degerler **SinifSistemi'nin kendi config.yml'sinden** okunur, sen ayari
degistirdiginde test de kendini gunceller. Olcum icin attribute'un `getBaseValue()`
(modifiersiz) ve `getValue()` (modifierli) degerleri karsilastirilir — aradaki fark
tam olarak sinifin ekledigi seydir. Boylece "+2 kalp" gercekten +4.0 MAX_HEALTH mi,
"%20 hiz" gercekten 1.20 carpani mi diye kesin olcum yapilir.

Kapsam: max-can, zirh, zirh-saglamligi, geri-tepme-direnci, sans, etkilesim-menzili,
saldiri-hasari-yuzde, hareket-hizi-yuzde, saldiri-hizi-yuzde. Ayrica suikastci kilic
carpani, rahip can yenilemesi, okcu dusme hasari muafiyeti.

## 4. Ozel silahlar — genel exploit taramasi

Kesfedilen her silaha uygulanir:

- `/silah ver` gercekten 1 adet veriyor mu, PDC isareti basiliyor mu
- Bekleme suresinde 20 kez sag tik: esya kayboluyor mu, cogaliyor mu
- Creative modda ayni spam
- **Isim taklidi** — sadece `custom_name`'i kopyalanmis, PDC'siz sahte esya
  yetenegi tetikliyor mu
- Yetenek isletilirken esyayi yere atip geri alma → dupe
- Dort dunyada da yetenek etki uretiyor mu, konsola exception dusuyor mu

## 5. Kanli Savas Baltasi

Kanama, can emisi, yetenek beklemesi, beklemenin oyuncuya mi esyaya mi bagli oldugu,
sinif kisitinin hasari gercekten engelleyip engellemedigi, esyanin yipranip yipranmadigi.

## 6. Ruby ore (istege bagli)

`config.yml`'de `ruby.ore-blok` doldurulursa: demir/elmas kazmayla dusme olmamali,
netherite ile dusme orani olculur, Servet III ile mutlaka dusmeli.

---

## Yetenegi nasil tespit ediyor

Paper'da giden sohbet mesajlarini dinlemenin guvenilir bir yolu yok. Bot mesaja degil
**etkiye** bakiyor: menzile hareketsiz bir hedef koyar, sag tikar, hedefin cani azaldi
mi diye olcer.

Iki tuzak kapatildi:
- **Devam eden kanama.** Yetenek hedefe 5 saniyelik kanama uyguluyor; ikinci denemeyi
  erken yaparsan onceki kanama hala akiyor olur ve "yetenek yine calisti" sanilir.
  Her olcum icin taze hedef kurulur, olcumler arasi kanamanin bitmesi beklenir.
- **Dogal can yenilenmesi.** Artik sadece hedefin cani olculur; can emisi testinde
  aclik 10'a cekilerek dogal yenilenme kapatilir.

## Op hesabi bazi sonuclari bozar

`sinif.silah.serbest` izninin varsayilani **op**. Op bir hesapla test edersen silah
sinif kisiti tasarim geregi asilir. Bot bunu tespit edip acik yerine uyari yaziyor,
ama gercek kisiti olcmek istiyorsan op olmayan ikinci bir hesap kullan: ona sadece
`qatest.kullan` iznini ver.

---

## Kurulum

1. Bu klasoru bir GitHub reposuna push et. `.github/workflows/build.yml` otomatik
   derler; Actions sekmesinden `QATest` artifact'ini indir.
2. Jar'i exaroton panelinden `plugins/` klasorune yukle, sunucuyu yeniden baslat.
3. Oyunda op olarak `/qatest calistir`.

Yerel derlemek istersen JDK 25 + `gradle build`.

## Komutlar

```
/qatest calistir            hepsi (varsayilan)
/qatest calistir sunucu     sadece eklenti/dunya sagligi
/qatest calistir datapack   sadece datapack dosya analizi
/qatest calistir sinif      sadece sinif ozellikleri
/qatest calistir genel      sadece silah exploit taramasi
/qatest calistir balta      sadece Kanli Savas Baltasi
/qatest calistir ruby       sadece ore drop testleri
/qatest liste               gruplari listeler
/qatest dur                 testi keser, envanteri geri yukler
```

Sonuclar sohbete dokulur ve `plugins/QATest/rapor-<tarih>.md` dosyasina yazilir.

## Uyarilar

- **Test dunyasinda calistir.** Bot blok koyup kiriyor, zombi cagiriyor, sinifini
  degistiriyor, envanterini temizliyor. Envanter/mod/konum/can basta kaydedilip
  bitince geri yukleniyor ama yine de riskli.
- Test sirasinda hareket etme, bot senin konumuna gore hedef yerlestiriyor.
- Sinif testi zirhini cikariyor (ARMOR attribute'unu olcebilmek icin), bitince
  geri giydiriyor. Test bitince sinifin degismis olur — bot son adimda hangi
  sinifta kaldigini soyluyor.
- Tam tur yaklasik 4-6 dakika surer. Datapack ve sunucu analizi saniyeler icinde biter.
